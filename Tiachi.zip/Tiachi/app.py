from flask import Flask, render_template, request, redirect, flash
import smtplib
from email.message import EmailMessage

app = Flask(__name__)
app.secret_key = "some_secret_key"

REGISTERED_EMAIL = "contact@tiachi.co.in"

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/products')
def products():
    # For now, static products data (you can connect DB later)
    products = [
        {'name': 'Green  Tea', 'image': 'product-1.jpg','description': ' Green tea is a refreshing, antioxidant-rich beverage known for its health benefits and soothing flavor.'},
        {'name': 'Black Tea', 'image': 'product-2.jpg', 'description':'Black tea is a bold, full-bodied tea known for its rich flavor and higher caffeine content.'},
        {'name': 'Green  Tea', 'image': 'product-1.jpg','description': ' Green tea is a refreshing, antioxidant-rich beverage known for its health benefits and soothing flavor.'},
        {'name': 'Black Tea', 'image': 'product-2.jpg','description':'Black tea is a bold, full-bodied tea known for its rich flavor and higher caffeine content.'},
    ]
    return render_template('products.html', products=products)



@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')

        # Validate inputs (optional)

        # Create email message
        email_message = EmailMessage()
        email_message['Subject'] = f"New Contact Message from {name}"
        email_message['From'] = email  # sender's email
        email_message['To'] = REGISTERED_EMAIL
        email_message.set_content(f"Name: {name}\nEmail: {email}\n\nMessage:\n{message}")

        # Send email (using SMTP)
        try:
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
                smtp.login('your_email@gmail.com', 'your_app_password')  # Use app password or appropriate credentials
                smtp.send_message(email_message)
            flash("Message sent successfully!", "success")
        except Exception as e:
            print(e)
            flash("Failed to send message.", "danger")

        return redirect('/contact')

    return render_template('contact.html')


@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)
